#!/usr/bin/env python3
from bot.TGBot import main

main()

if __name__ == '__main__':
    main()
